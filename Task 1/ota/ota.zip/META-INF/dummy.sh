sed -i "/return 0/i /system/xbin/dummy.sh" /android/system/etc/init.sh
